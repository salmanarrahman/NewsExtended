package com.sallu.newsex.Utils;

public class Config {
    public static final String DATABASE_NAME = "CATEGORY";
    public static final String  NEWS_CATEGORIES = "News by Categories";
    public static final String  TRENDING = "Trending";
    public static final String  FAVORITE = "Favorite";
    public static final String  PHOTOS = "Photos";
    public static final String  BRAKING_NEWS = "Braking News";
    public static final String  VIDEOS = "Videos";

    public static final String API_KEY = "AIzaSyCs1olguShw-dkgKymcLvFwYWluoSh4vno";

    public static final String TOPIC_GLOBAL = "global";


    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String PUSH_NOTIFICATION = "pushNotification";



}
